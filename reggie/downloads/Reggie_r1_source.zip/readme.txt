=== Reggie! Level Editor (Release 1) ===

Advanced level editor for New Super Mario Bros. Wii, created by Treeki and
Tempus using Python, PyQt and Wii.py.

Homepage: http://www.rvlution.net/reggie/
Support:  http://www.rvlution.net/forums/

Source code package for this release:
- http://www.rvlution.net/reggie/downloads/Reggie_r1_source.zip


=== Changelog: ===

Release 1: (March 19th, 2010)
- Reggie! is finally released after 4 months of work and 18 test builds!
- First release, may have bugs or incomplete sprites. Report any errors to us
  at the forums (link above).


=== Requirements: ===

If you are using the source release:
- Python 2.5 (or newer) - http://www.python.org
- PyQt 4.6 (or newer) - http://www.riverbankcomputing.co.uk/software/pyqt/intro
- NSMBLib 0.4 - included with the source package (optional)

If you have a prebuilt/frozen release (for Windows or Mac OS)
you don't need to install anything - all the required libraries are included.

For more information on running Reggie from source and getting the required
libraries, check the Getting Started page inside the help file
(located at reggiedata/help/start.html within the archive)


=== Reggie! Team: ===

Developers:
- Treeki - Creator, Programmer, Data, RE
- Tempus - Programmer, Graphics, Data
- AerialX - CheerIOS, Riivolution
- megazig - Code, Optimisation, Data, RE
- Omega - int(), Python, Testing
- Pop006 - Sprite Images
- Tobias Amaranth - Sprite Info (a lot of it), Event Example Stage

Other Testers and Contributors:
- BulletBillTime, Dirbaio, EdgarAllen, FirePhoenix, GrandMasterJimmy,
  Mooseknuckle2000, MotherBrainsBrain, RainbowIE, Skawo, Sonicandtails,
  Tanks, Vibestar

- Tobias Amaranth and Valeth - Text Tileset Addon


=== Libraries/Resources: ===

Qt - Nokia (http://qt.nokia.com)
PyQt - Riverbank Computing (http://www.riverbankcomputing.co.uk/software/pyqt/intro)
Wii.py - megazig, Xuzz, The Lemon Man, Matt_P, SquidMan, Omega (http://github.com/icefire/Wii.py)
Interface Icons - Yusuke Kamiyamane (http://www.pinvoke.com)


=== Licensing: ===

Reggie! is released under the GNU General Public License v2.
See the license file in the distribution for information.
