Version 5 of a Riivolution XML Schema

1.) Place RiivolutionV1.xsd and a copy of XMLTemplate.xml in a directory
2.) Open the copy of the template with an XML-capable editor (visual Studio, etc)

Current bugs/missing features:

The required fields for <memory> are not all set as required--make sure you are setting everything you need!
